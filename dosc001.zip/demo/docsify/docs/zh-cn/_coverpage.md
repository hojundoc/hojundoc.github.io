<!-- _coverpage.md -->

![logo](https://docsify.js.org/_media/icon.svg)

# docsify 这是中文首页 <small>3.5</small>

> A magical documentation site generator.

- Simple and lightweight (~21kB gzipped)
- No statically built html files
- Multiple themes

[GitHub](https://github.com/docsifyjs/docsify/)
[Get Started](#docsify)

<!-- background image -->

![](https://docsify.js.org/_media/icon.svg)

<!-- background color -->

![color](#f0f0f0)